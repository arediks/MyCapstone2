package com.example.mygithub.core.domain.model

data class GitUsers(
    val login: String,
    val avatarUrl: String
)