MyCapstone2
=========================
[![arediks](https://dl.circleci.com/status-badge/img/gh/arediks/MyCapstone2/tree/master.svg?style=svg&circle-token=CCIPRJ_WAWZSUtDTpEvsgkJL15T5k_67cc0ef3186f6a4e485925f1895995c7fcc9593d)](https://dl.circleci.com/status-badge/redirect/gh/arediks/MyCapstone2/tree/master)

This project was created for Capstone 2 "Menjadi Android Developer Expert" Dicoding Submission.
